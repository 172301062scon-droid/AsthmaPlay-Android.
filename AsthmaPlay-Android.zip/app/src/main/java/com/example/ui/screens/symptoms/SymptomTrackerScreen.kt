package com.example.ui.screens.symptoms

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.SymptomLog
import com.example.data.models.SymptomSeverity
import com.example.ui.theme.*

@Composable
fun SymptomTrackerScreen(
    symptomLogs: List<SymptomLog>,
    onSaveLog: (SymptomSeverity, List<String>, List<String>, String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTimeTab by remember { mutableIntStateOf(0) } // 0 = Today, 1 = Week, 2 = Month
    var selectedSeverity by remember { mutableStateOf(SymptomSeverity.GOOD) }

    val availableSymptoms = listOf("Cough", "Wheezing", "Shortness of breath", "Chest tightness", "Nighttime waking")
    val selectedSymptoms = remember { mutableStateListOf<String>() }

    val availableTriggers = listOf("Cold air", "Exercise / Running", "Pollen", "Pet dander", "Dust mites", "Smoke / Fumes")
    val selectedTriggers = remember { mutableStateListOf<String>() }

    var notesText by remember { mutableStateOf("") }
    var saveSuccessMessage by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Symptom Tracker",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFC2185B)
                    )
                    Text(
                        text = "Track daily how your lungs feel",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFFF8FBFE))
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 48.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Period Tabs
            item {
                TabRow(
                    selectedTabIndex = selectedTimeTab,
                    containerColor = Color.White,
                    contentColor = SkyBlueDark,
                    modifier = Modifier.clip(RoundedCornerShape(14.dp))
                ) {
                    Tab(selected = selectedTimeTab == 0, onClick = { selectedTimeTab = 0 }, text = { Text("Today") })
                    Tab(selected = selectedTimeTab == 1, onClick = { selectedTimeTab = 1 }, text = { Text("Week") })
                    Tab(selected = selectedTimeTab == 2, onClick = { selectedTimeTab = 2 }, text = { Text("Month") })
                }
            }

            // Severity Selector Card: How are you feeling today?
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "How are you feeling today?",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B)
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            SymptomSeverity.values().forEach { severity ->
                                val isSelected = selectedSeverity == severity
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(if (isSelected) SkyBlueLight else Color.Transparent)
                                        .clickable { selectedSeverity = severity }
                                        .padding(horizontal = 10.dp, vertical = 8.dp)
                                        .testTag("severity_${severity.name.lowercase()}")
                                ) {
                                    Text(text = severity.emoji, fontSize = 34.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = severity.name.lowercase().replaceFirstChar { it.uppercase() },
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) SkyBlueDark else Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Symptoms Checklist
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Any symptoms today? (Select all that apply)",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        availableSymptoms.forEach { symptom ->
                            val isChecked = selectedSymptoms.contains(symptom)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        if (isChecked) selectedSymptoms.remove(symptom)
                                        else selectedSymptoms.add(symptom)
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { checked ->
                                        if (checked) selectedSymptoms.add(symptom)
                                        else selectedSymptoms.remove(symptom)
                                    }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = symptom, fontSize = 14.sp, color = Color(0xFF334155))
                            }
                        }
                    }
                }
            }

            // Triggers Checklist
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Possible Triggers Noticed",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        availableTriggers.forEach { trigger ->
                            val isChecked = selectedTriggers.contains(trigger)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        if (isChecked) selectedTriggers.remove(trigger)
                                        else selectedTriggers.add(trigger)
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { checked ->
                                        if (checked) selectedTriggers.add(trigger)
                                        else selectedTriggers.remove(trigger)
                                    }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = trigger, fontSize = 14.sp, color = Color(0xFF334155))
                            }
                        }
                    }
                }
            }

            // Observations / Notes
            item {
                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Parent / Child Notes (Optional)") },
                    placeholder = { Text("e.g. Played soccer at 3pm, took 1 puff before game") },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("symptom_notes_input"),
                    minLines = 2
                )
            }

            // Safety notice
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "ℹ️ Note: This symptom tracker is strictly for recording personal daily notes and is not an emergency monitor. In case of breathing difficulty, alert an adult immediately.",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B),
                        modifier = Modifier.padding(12.dp),
                        lineHeight = 15.sp
                    )
                }
            }

            // Save Entry Button
            item {
                Button(
                    onClick = {
                        onSaveLog(selectedSeverity, selectedSymptoms.toList(), selectedTriggers.toList(), notesText)
                        saveSuccessMessage = true
                        notesText = ""
                        selectedSymptoms.clear()
                        selectedTriggers.clear()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SkyBlueDark),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("save_symptom_button")
                ) {
                    Text("Save Today's Entry (+10 XP)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Past History Section
            item {
                Text(
                    text = "Recent Logs",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )
            }

            items(symptomLogs) { log ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = log.severity.emoji, fontSize = 22.sp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = log.severity.label,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(log.severity.colorHex)
                                )
                            }
                            Text(text = log.dateString, fontSize = 11.sp, color = Color.Gray)
                        }

                        if (log.symptoms.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Symptoms: ${log.symptoms.joinToString(", ")}",
                                fontSize = 12.sp,
                                color = Color(0xFF334155)
                            )
                        }

                        if (log.triggers.isNotEmpty()) {
                            Text(
                                text = "Triggers: ${log.triggers.joinToString(", ")}",
                                fontSize = 12.sp,
                                color = Color(0xFF64748B)
                            )
                        }

                        if (log.notes.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Notes: ${log.notes}",
                                fontSize = 12.sp,
                                color = Color(0xFF475569),
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                            )
                        }
                    }
                }
            }
        }
    }
}
