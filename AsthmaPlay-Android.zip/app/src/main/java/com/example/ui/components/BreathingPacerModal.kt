package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.SkyBlueDark
import com.example.ui.theme.SkyBluePrimary
import com.example.ui.theme.TealAccent
import kotlinx.coroutines.delay

@Composable
fun BreathingPacerModal(
    onDismiss: () -> Unit,
    onCompleted: () -> Unit
) {
    var cycleState by remember { mutableStateOf("Breathe In...") }
    var secondsRemaining by remember { mutableStateOf(4) }
    var completedRounds by remember { mutableStateOf(0) }

    // Breathing cycle: Inhale (4s), Hold (2s), Exhale (4s)
    LaunchedEffect(Unit) {
        while (completedRounds < 3) {
            cycleState = "Breathe in slowly..."
            for (i in 4 downTo 1) {
                secondsRemaining = i
                delay(1000)
            }

            cycleState = "Gently hold..."
            for (i in 2 downTo 1) {
                secondsRemaining = i
                delay(1000)
            }

            cycleState = "Slowly breathe out..."
            for (i in 4 downTo 1) {
                secondsRemaining = i
                delay(1000)
            }

            completedRounds++
        }
        cycleState = "Great Job! You did it! 🌟"
        delay(1200)
        onCompleted()
    }

    val infiniteTransition = rememberInfiniteTransition(label = "breathe_pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("breathing_pacer_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Relaxed Breathing",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = SkyBlueDark
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Breathe along with your happy lung buddy to relax your chest and mind.",
                    fontSize = 13.sp,
                    color = Color.DarkGray,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(28.dp))

                Box(
                    modifier = Modifier
                        .size(180.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Outer glowing pulsing circle
                    Box(
                        modifier = Modifier
                            .size((140 * scale).dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(SkyBluePrimary.copy(alpha = 0.45f), TealAccent.copy(alpha = 0.1f))
                                )
                            )
                    )

                    // Center Mascot Lung / Bubble
                    Box(
                        modifier = Modifier
                            .size(110.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(listOf(SkyBlueDark, TealAccent))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "🫁", fontSize = 36.sp)
                            Text(
                                text = "$secondsRemaining s",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = cycleState,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = SkyBlueDark,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Rounds completed: $completedRounds of 3",
                    fontSize = 12.sp,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = SkyBlueDark),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (completedRounds >= 3) "Awesome! Close" else "Done Practicing")
                }
            }
        }
    }
}
