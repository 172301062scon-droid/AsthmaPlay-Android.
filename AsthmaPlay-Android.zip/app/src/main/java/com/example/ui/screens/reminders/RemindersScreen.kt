package com.example.ui.screens.reminders

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.MedicationReminder
import com.example.data.models.MedicationType
import com.example.ui.theme.*

@Composable
fun RemindersScreen(
    reminders: List<MedicationReminder>,
    onToggleReminder: (String) -> Unit,
    onMarkTaken: (String) -> Unit,
    onAddReminder: (String, MedicationType, String, String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Medication & Clinic Reminders",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = SkyBlueDark
                    )
                    Text(
                        text = "Configured by parents & clinicians",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = SkyBlueDark,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Add Reminder") },
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("add_reminder_fab")
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFFF8FBFE))
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SkyBlueLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🔔", fontSize = 24.sp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Reminders help you remember scheduled doses. Tap the checkmark after taking your puff to log it!",
                            fontSize = 12.sp,
                            color = SkyBlueDark,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            items(reminders) { reminder ->
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(
                                    when (reminder.type) {
                                        MedicationType.RELIEVER -> SkyBlueLight
                                        MedicationType.CONTROLLER -> WarmOrangeLight
                                        MedicationType.APPOINTMENT -> RoyalPurpleLight
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = when (reminder.type) {
                                    MedicationType.RELIEVER -> "💨"
                                    MedicationType.CONTROLLER -> "🛡️"
                                    MedicationType.APPOINTMENT -> "🏥"
                                },
                                fontSize = 24.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = reminder.title,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B)
                            )
                            Text(
                                text = "${reminder.timeString} • ${reminder.dosageNotes}",
                                fontSize = 12.sp,
                                color = Color(0xFF64748B)
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                FilterChip(
                                    selected = reminder.isTakenToday,
                                    onClick = { onMarkTaken(reminder.id) },
                                    label = {
                                        Text(
                                            if (reminder.isTakenToday) "Taken Today ✓" else "Mark Taken",
                                            fontSize = 11.sp
                                        )
                                    },
                                    leadingIcon = if (reminder.isTakenToday) {
                                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                    } else null,
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = SoftGreenLight,
                                        selectedLabelColor = SoftGreenDark
                                    )
                                )
                            }
                        }

                        Switch(
                            checked = reminder.isEnabled,
                            onCheckedChange = { onToggleReminder(reminder.id) },
                            colors = SwitchDefaults.colors(checkedThumbColor = SkyBlueDark)
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var newTitle by remember { mutableStateOf("") }
        var newDosage by remember { mutableStateOf("1 puff with spacer") }
        var newTime by remember { mutableStateOf("8:00 AM") }
        var newType by remember { mutableStateOf(MedicationType.CONTROLLER) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Medication Reminder", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("Medicine or Appointment Name") },
                        placeholder = { Text("e.g. Bedtime Controller Inhaler") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newDosage,
                        onValueChange = { newDosage = it },
                        label = { Text("Dosage Notes") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = newTime,
                        onValueChange = { newTime = it },
                        label = { Text("Scheduled Time") },
                        placeholder = { Text("e.g. 8:00 PM") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = newType == MedicationType.CONTROLLER,
                            onClick = { newType = MedicationType.CONTROLLER },
                            label = { Text("Controller", fontSize = 11.sp) }
                        )
                        FilterChip(
                            selected = newType == MedicationType.RELIEVER,
                            onClick = { newType = MedicationType.RELIEVER },
                            label = { Text("Reliever", fontSize = 11.sp) }
                        )
                        FilterChip(
                            selected = newType == MedicationType.APPOINTMENT,
                            onClick = { newType = MedicationType.APPOINTMENT },
                            label = { Text("Clinic", fontSize = 11.sp) }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newTitle.isNotBlank()) {
                            onAddReminder(newTitle, newType, newTime, newDosage)
                            showAddDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SkyBlueDark)
                ) {
                    Text("Save Reminder")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
