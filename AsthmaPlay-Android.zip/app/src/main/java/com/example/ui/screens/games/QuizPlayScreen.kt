package com.example.ui.screens.games

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Quiz
import com.example.ui.theme.*

@Composable
fun QuizPlayScreen(
    quiz: Quiz,
    onBack: () -> Unit,
    onQuizCompleted: (String, Int, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var currentIndex by remember { mutableIntStateOf(0) }
    var selectedOption by remember { mutableStateOf<Int?>(null) }
    var isAnswerSubmitted by remember { mutableStateOf(false) }
    var totalScore by remember { mutableIntStateOf(0) }
    var isQuizFinished by remember { mutableStateOf(false) }

    val currentQuestion = quiz.questions.getOrNull(currentIndex)
    val progress = if (quiz.questions.isNotEmpty()) (currentIndex + 1).toFloat() / quiz.questions.size else 0f

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isQuizFinished) "Results" else "Quiz Time!",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = SkyBlueDark,
                    modifier = Modifier.weight(1f)
                )

                // Stars score pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = GoldenYellowLight,
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(GoldenYellow))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = GoldenYellow,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${totalScore * 10} XP",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB45309)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        if (isQuizFinished) {
            // Quiz Complete Screen (from visual mockup)
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .background(Color(0xFFF8FBFE))
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .clip(CircleShape)
                        .background(GoldenYellowLight),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "⭐", fontSize = 72.sp)
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Quiz Complete!",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = SkyBlueDark
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "You scored",
                    fontSize = 16.sp,
                    color = Color.Gray
                )

                Text(
                    text = "$totalScore / ${quiz.questions.size}",
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Black,
                    color = if (totalScore >= (quiz.questions.size * 0.7)) SoftGreen else WarmOrange
                )

                Text(
                    text = if (totalScore == quiz.questions.size) "Perfect Score! You're a Breathing Champion! 🏆"
                    else "Great job! You're learning how to keep your lungs healthy!",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF334155),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(20.dp))

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SoftGreenLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🌟", fontSize = 28.sp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "+${totalScore * 10} points awarded!",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = SoftGreenDark
                            )
                            Text(
                                text = "Your points help Arjun level up as an Airway Hero!",
                                fontSize = 12.sp,
                                color = SoftGreenDark
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                Button(
                    onClick = {
                        onQuizCompleted(quiz.id, totalScore, quiz.questions.size)
                        onBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SkyBlueDark),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("quiz_finish_button")
                ) {
                    Text("Back to Games Hub", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        } else if (currentQuestion != null) {
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .background(Color(0xFFF8FBFE))
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Progress
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Question ${currentIndex + 1} of ${quiz.questions.size}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.Gray
                        )
                        Text(
                            text = "${(progress * 100).toInt()}%",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = SkyBlueDark
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape),
                        color = SkyBlueDark,
                        trackColor = Color(0xFFE2E8F0)
                    )
                }

                // Question Card
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = currentQuestion.question,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            lineHeight = 24.sp
                        )
                    }
                }

                // Options list
                currentQuestion.options.forEachIndexed { optIndex, optText ->
                    val optionLetters = listOf("A", "B", "C", "D")
                    val letter = optionLetters.getOrElse(optIndex) { "${optIndex + 1}" }
                    val isSelected = selectedOption == optIndex
                    val isCorrect = optIndex == currentQuestion.correctIndex

                    val borderColor = when {
                        isAnswerSubmitted && isCorrect -> SoftGreen
                        isAnswerSubmitted && isSelected && !isCorrect -> EmergencyRed
                        isSelected -> SkyBlueDark
                        else -> Color(0xFFE2E8F0)
                    }

                    val bgColor = when {
                        isAnswerSubmitted && isCorrect -> SoftGreenLight
                        isAnswerSubmitted && isSelected && !isCorrect -> EmergencyRedLight
                        isSelected -> SkyBlueLight
                        else -> Color.White
                    }

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = bgColor),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(2.dp, borderColor, RoundedCornerShape(16.dp))
                            .clickable(enabled = !isAnswerSubmitted) {
                                selectedOption = optIndex
                            }
                            .testTag("quiz_option_$optIndex")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) SkyBlueDark else Color(0xFFF1F5F9)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = letter,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else Color(0xFF475569)
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Text(
                                text = optText,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF1E293B),
                                modifier = Modifier.weight(1f)
                            )

                            if (isAnswerSubmitted && isCorrect) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Correct",
                                    tint = SoftGreen
                                )
                            }
                        }
                    }
                }

                // Explanation after answering
                if (isAnswerSubmitted) {
                    val wasCorrect = selectedOption == currentQuestion.correctIndex
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (wasCorrect) SoftGreenLight else WarmOrangeLight
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(text = if (wasCorrect) "🌟" else "💡", fontSize = 24.sp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (wasCorrect) "Great job! +10 points" else "Keep learning!",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (wasCorrect) SoftGreenDark else Color(0xFFC05621)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = currentQuestion.explanation,
                                    fontSize = 13.sp,
                                    color = Color(0xFF334155),
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Bottom Action Button: Submit or Next
                if (!isAnswerSubmitted) {
                    Button(
                        onClick = {
                            if (selectedOption != null) {
                                isAnswerSubmitted = true
                                if (selectedOption == currentQuestion.correctIndex) {
                                    totalScore++
                                }
                            }
                        },
                        enabled = selectedOption != null,
                        colors = ButtonDefaults.buttonColors(containerColor = SkyBlueDark),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("quiz_submit_button")
                    ) {
                        Text("Submit Answer", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = {
                            if (currentIndex + 1 < quiz.questions.size) {
                                currentIndex++
                                selectedOption = null
                                isAnswerSubmitted = false
                            } else {
                                isQuizFinished = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SkyBlueDark),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("quiz_next_button")
                    ) {
                        Text(
                            text = if (currentIndex + 1 < quiz.questions.size) "Next Question →" else "See Quiz Results 🏆",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
