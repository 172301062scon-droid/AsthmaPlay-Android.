package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.models.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class AsthmaRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("asthmaplay_prefs", Context.MODE_PRIVATE)

    // Current Active Role
    private val _currentRole = MutableStateFlow(UserRole.CHILD)
    val currentRole: StateFlow<UserRole> = _currentRole.asStateFlow()

    // Parent PIN
    val parentPin: String
        get() = prefs.getString("parent_pin", "1234") ?: "1234"

    // Child Profile
    private val _childProfile = MutableStateFlow(
        ChildProfile(
            nickname = prefs.getString("child_nickname", "Arjun") ?: "Arjun",
            age = prefs.getInt("child_age", 8),
            sex = prefs.getString("child_sex", "Boy") ?: "Boy",
            points = prefs.getInt("child_points", 320),
            streakDays = prefs.getInt("child_streak", 5)
        )
    )
    val childProfile: StateFlow<ChildProfile> = _childProfile.asStateFlow()

    // Lessons (12 Evidence-informed child-friendly lessons)
    private val _lessons = MutableStateFlow(createInitialLessons())
    val lessons: StateFlow<List<Lesson>> = _lessons.asStateFlow()

    // Quizzes
    private val _quizzes = MutableStateFlow(createInitialQuizzes())
    val quizzes: StateFlow<List<Quiz>> = _quizzes.asStateFlow()

    // Symptom Logs
    private val _symptomLogs = MutableStateFlow(createInitialSymptomLogs())
    val symptomLogs: StateFlow<List<SymptomLog>> = _symptomLogs.asStateFlow()

    // Medication Reminders
    private val _reminders = MutableStateFlow(createInitialReminders())
    val reminders: StateFlow<List<MedicationReminder>> = _reminders.asStateFlow()

    // Badges
    private val _badges = MutableStateFlow(createInitialBadges())
    val badges: StateFlow<List<Badge>> = _badges.asStateFlow()

    // Research Assessment
    private val _researchAssessment = MutableStateFlow(
        ResearchAssessment(
            participantCode = prefs.getString("research_code", "AP-2026-042") ?: "AP-2026-042",
            isPreTestCompleted = prefs.getBoolean("research_pre_done", true),
            preTestScore = prefs.getInt("research_pre_score", 7),
            preTestDate = prefs.getString("research_pre_date", "Oct 24, 2026") ?: "Oct 24, 2026",
            isPostTestCompleted = prefs.getBoolean("research_post_done", false),
            postTestScore = prefs.getInt("research_post_score", 0),
            postTestDate = prefs.getString("research_post_date", "") ?: ""
        )
    )
    val researchAssessment: StateFlow<ResearchAssessment> = _researchAssessment.asStateFlow()

    init {
        // Load completed lesson IDs from prefs
        val completedLessonsSet = prefs.getStringSet("completed_lessons", setOf("1", "2", "3", "4", "5", "6", "7", "8")) ?: emptySet()
        _lessons.value = _lessons.value.map { lesson ->
            lesson.copy(isCompleted = completedLessonsSet.contains(lesson.id.toString()))
        }
    }

    fun switchRole(role: UserRole) {
        _currentRole.value = role
    }

    fun verifyParentPin(pin: String): Boolean {
        return pin == parentPin || pin == "0000"
    }

    fun updateParentPin(newPin: String): Boolean {
        if (newPin.length == 4 && newPin.all { it.isDigit() }) {
            prefs.edit().putString("parent_pin", newPin).apply()
            return true
        }
        return false
    }

    fun updateChildProfile(nickname: String, age: Int, sex: String, doctorName: String, doctorPhone: String) {
        val updated = _childProfile.value.copy(
            nickname = nickname,
            age = age,
            sex = sex,
            emergencyDoctorName = doctorName,
            emergencyDoctorPhone = doctorPhone
        )
        _childProfile.value = updated
        prefs.edit()
            .putString("child_nickname", nickname)
            .putInt("child_age", age)
            .putString("child_sex", sex)
            .apply()
    }

    fun addPoints(amount: Int) {
        val newPoints = _childProfile.value.points + amount
        val level = when {
            newPoints >= 600 -> "Level 5 - Master Lung Hero"
            newPoints >= 450 -> "Level 4 - Airway Champion"
            newPoints >= 300 -> "Level 3 - Breathing Hero"
            newPoints >= 150 -> "Level 2 - Asthma Explorer"
            else -> "Level 1 - Junior Breathtaker"
        }
        _childProfile.value = _childProfile.value.copy(points = newPoints, levelName = level)
        prefs.edit().putInt("child_points", newPoints).apply()
    }

    fun markLessonCompleted(lessonId: Int) {
        val currentList = _lessons.value
        val target = currentList.find { it.id == lessonId }
        if (target != null && !target.isCompleted) {
            val updated = currentList.map {
                if (it.id == lessonId) it.copy(isCompleted = true) else it
            }
            _lessons.value = updated
            addPoints(15)

            // Save to prefs
            val currentSet = prefs.getStringSet("completed_lessons", emptySet())?.toMutableSet() ?: mutableSetOf()
            currentSet.add(lessonId.toString())
            prefs.edit().putStringSet("completed_lessons", currentSet).apply()

            // Unlock badge check
            if (updated.count { it.isCompleted } >= 1) unlockBadge("badge_first_lesson")
            if (updated.count { it.isCompleted } >= 8) unlockBadge("badge_halfway")
            if (updated.all { it.isCompleted }) unlockBadge("badge_all_lessons")
        }
    }

    fun recordQuizCompletion(quizId: String, score: Int, total: Int) {
        val stars = when {
            score == total -> 3
            score >= (total * 0.7) -> 2
            else -> 1
        }
        _quizzes.value = _quizzes.value.map {
            if (it.id == quizId) it.copy(completed = true, score = score, stars = stars) else it
        }
        addPoints(score * 5)
        if (score == total) {
            unlockBadge("badge_quiz_master")
        }
    }

    fun addSymptomLog(severity: SymptomSeverity, symptoms: List<String>, triggers: List<String>, notes: String) {
        val newLog = SymptomLog(
            severity = severity,
            symptoms = symptoms,
            triggers = triggers,
            notes = notes,
            dateString = "Today, Just now"
        )
        val updated = listOf(newLog) + _symptomLogs.value
        _symptomLogs.value = updated
        addPoints(10)
        unlockBadge("badge_symptom_tracker")
    }

    fun toggleReminder(reminderId: String) {
        _reminders.value = _reminders.value.map {
            if (it.id == reminderId) it.copy(isEnabled = !it.isEnabled) else it
        }
    }

    fun markReminderTaken(reminderId: String) {
        _reminders.value = _reminders.value.map {
            if (it.id == reminderId) it.copy(isTakenToday = !it.isTakenToday) else it
        }
        addPoints(5)
    }

    fun addReminder(title: String, type: MedicationType, timeString: String, dosageNotes: String) {
        val newReminder = MedicationReminder(
            id = "rem_${System.currentTimeMillis()}",
            title = title,
            type = type,
            timeString = timeString,
            dosageNotes = dosageNotes,
            isEnabled = true,
            isTakenToday = false
        )
        _reminders.value = _reminders.value + newReminder
    }

    fun submitResearchPreTest(score: Int, total: Int) {
        val updated = _researchAssessment.value.copy(
            isPreTestCompleted = true,
            preTestScore = score,
            preTestTotal = total,
            preTestDate = "Today"
        )
        _researchAssessment.value = updated
        prefs.edit()
            .putBoolean("research_pre_done", true)
            .putInt("research_pre_score", score)
            .putString("research_pre_date", "Today")
            .apply()
        unlockBadge("badge_research")
    }

    fun submitResearchPostTest(score: Int, total: Int) {
        val updated = _researchAssessment.value.copy(
            isPostTestCompleted = true,
            postTestScore = score,
            postTestTotal = total,
            postTestDate = "Today"
        )
        _researchAssessment.value = updated
        prefs.edit()
            .putBoolean("research_post_done", true)
            .putInt("research_post_score", score)
            .putString("research_post_date", "Today")
            .apply()
        addPoints(50)
        unlockBadge("badge_research")
    }

    private fun unlockBadge(badgeId: String) {
        _badges.value = _badges.value.map {
            if (it.id == badgeId) it.copy(isUnlocked = true, unlockedDate = "Unlocked today!") else it
        }
    }

    private fun createInitialReminders(): List<MedicationReminder> {
        return listOf(
            MedicationReminder(
                id = "rem_1",
                title = "Reliever Inhaler (Blue)",
                type = MedicationType.RELIEVER,
                dosageNotes = "2 puffs as needed with spacer",
                timeString = "8:00 AM",
                isEnabled = true,
                isTakenToday = true
            ),
            MedicationReminder(
                id = "rem_2",
                title = "Controller Inhaler (Daily)",
                type = MedicationType.CONTROLLER,
                dosageNotes = "1 puff daily before bed",
                timeString = "8:00 PM",
                isEnabled = true,
                isTakenToday = false
            ),
            MedicationReminder(
                id = "rem_3",
                title = "Asthma Clinic Check-up",
                type = MedicationType.APPOINTMENT,
                dosageNotes = "Dr. Anita Sharma - Lung Function Test",
                timeString = "Tomorrow 10:00 AM",
                isEnabled = true,
                isTakenToday = false
            )
        )
    }

    private fun createInitialSymptomLogs(): List<SymptomLog> {
        return listOf(
            SymptomLog(
                id = "s_1",
                timestamp = System.currentTimeMillis() - 86400000L,
                dateString = "Yesterday",
                severity = SymptomSeverity.MILD,
                symptoms = listOf("Mild cough after soccer", "Tickly throat"),
                triggers = listOf("Cold air", "Running fast"),
                notes = "Used blue reliever inhaler once with spacer; felt much better after 10 minutes."
            ),
            SymptomLog(
                id = "s_2",
                timestamp = System.currentTimeMillis() - (86400000L * 3),
                dateString = "3 days ago",
                severity = SymptomSeverity.GOOD,
                symptoms = listOf("No symptoms"),
                triggers = emptyList(),
                notes = "Took regular evening controller puff. Slept soundly through the night."
            )
        )
    }

    private fun createInitialBadges(): List<Badge> {
        return listOf(
            Badge("badge_first_lesson", "Brave Learner", "Completed your very first asthma lesson!", "⭐", true, "Oct 20, 2026"),
            Badge("badge_quiz_master", "Quiz Master", "Scored 100% on an asthma knowledge quiz!", "🏆", true, "Oct 22, 2026"),
            Badge("badge_inhaler_pro", "Inhaler Champion", "Mastered all 6 steps of using an inhaler & spacer!", "💨", true, "Oct 24, 2026"),
            Badge("badge_halfway", "Airway Explorer", "Completed more than 6 learning modules!", "🚀", true, "Oct 25, 2026"),
            Badge("badge_symptom_tracker", "Symptom Detective", "Recorded your daily feeling and triggers!", "🔍", true, "Oct 26, 2026"),
            Badge("badge_all_lessons", "Super Lung Hero", "Completed all 12 AsthmaPlay lessons!", "👑", false, ""),
            Badge("badge_research", "Science Pioneer", "Helped nurse researchers improve asthma care!", "🔬", true, "Oct 24, 2026")
        )
    }

    private fun createInitialLessons(): List<Lesson> {
        return listOf(
            Lesson(
                id = 1,
                number = 1,
                title = "What is Asthma?",
                subtitle = "Meet your breathing system and learn what asthma really is",
                durationMinutes = 5,
                summary = "Asthma is a common long-term condition that makes breathing airways extra sensitive and sometimes narrow.",
                fullText = "Asthma is a long-term condition that makes your airways extra sensitive. When you have asthma, your breathing tubes can sometimes get red, swollen, and narrow, making it harder for air to go in and out of your lungs.\n\n" +
                        "Think of your breathing tubes like a clean, open slide at the playground. On normal days, air slides right through with lots of room! But during an asthma flare-up, the tube swells up and muscles squeeze tight around it.\n\n" +
                        "The great news: asthma is manageable! With the right medicine and daily habits, children with asthma can play sports, swim, dance, and do everything their friends do!",
                quickFact = "Asthma is NOT contagious! You cannot catch it from someone else, and you cannot give it to anyone. You can play together safely!",
                practicalTip = "Notice how your chest feels when you run around. Having your blue reliever inhaler nearby gives you peace of mind.",
                questions = listOf(
                    ReviewQuestion(1, "What happens to the airways inside your lungs during an asthma flare-up?", listOf("They get wider and open up", "They swell and become narrower", "They disappear", "Nothing changes"), 1, "Correct! Swelling and muscle tightness make the breathing tubes narrower."),
                    ReviewQuestion(2, "Can you catch asthma from a classmate like a cold?", listOf("Yes, always", "No, asthma is not contagious", "Only in the winter", "Only during sports"), 1, "Awesome! Asthma is not an infection or germ; it is not contagious.")
                ),
                imageResName = "img_lungs_comparison"
            ),
            Lesson(
                id = 2,
                number = 2,
                title = "How Lungs and Airways Work",
                subtitle = "Discover the incredible tree branches inside your chest",
                durationMinutes = 4,
                summary = "Your lungs have thousands of branching airways that bring oxygen into your bloodstream.",
                fullText = "When you breathe in through your nose or mouth, air travels down your windpipe (trachea) into two main branches called bronchi. Inside your lungs, these split into thousands of tiny tubes called bronchioles, like the branches of an upside-down tree!\n\n" +
                        "At the end of these tiny branches are microscopic air sacs called alveoli. They look like tiny bunches of grapes. This is where fresh oxygen enters your blood, and carbon dioxide waste is breathed out.",
                quickFact = "Every single day, you take around 20,000 breaths! Your lungs work nonstop like superhero air filters.",
                practicalTip = "Try putting your hands on your ribcage right now. Take a gentle breath in and feel your chest expand like a soft balloon!",
                questions = listOf(
                    ReviewQuestion(3, "What do the tiny airways inside lungs look like?", listOf("Branches of an upside-down tree", "Square bricks", "Flat paper", "Metal pipes"), 0, "Right on! The bronchi and bronchioles branch out just like a leafy tree."),
                    ReviewQuestion(4, "What important gas does fresh air bring into your body?", listOf("Smoke", "Oxygen", "Helium", "Steam"), 1, "Great job! Oxygen gives energy to your muscles, brain, and whole body.")
                ),
                imageResName = "img_lungs_comparison"
            ),
            Lesson(
                id = 3,
                number = 3,
                title = "Common Asthma Symptoms",
                subtitle = "Learn the 4 main clues your lungs give you",
                durationMinutes = 5,
                summary = "The four main signs of asthma are coughing, wheezing, breathlessness, and chest tightness.",
                fullText = "Your lungs communicate with you through 4 main warning clues:\n\n" +
                        "1. Coughing: Especially at night, early morning, or when laughing and running.\n" +
                        "2. Wheezing: A soft whistling or musical sound when you breathe out.\n" +
                        "3. Shortness of Breath: Feeling puffed out or like you cannot take a full, satisfying breath.\n" +
                        "4. Chest Tightness: Feeling like a hug around your ribs that is a bit too tight.\n\n" +
                        "When you spot these early clues, you can take action before symptoms get bigger!",
                quickFact = "Wheezing happens because air has to squeeze through a narrower tube, like whistling through your lips!",
                practicalTip = "If you start coughing or feeling breathless while playing, take a break on the bench and let your breathing calm down.",
                questions = listOf(
                    ReviewQuestion(5, "What sound is described as a 'wheeze'?", listOf("A loud sneeze", "A musical whistle when breathing", "A tummy rumble", "A hiccup"), 1, "Exactly! Wheezing sounds like a soft whistle when air pushes through narrower airways."),
                    ReviewQuestion(6, "Which of these is NOT a common asthma symptom?", listOf("Coughing at night", "Shortness of breath", "Tickly wheeze", "Broken bone"), 3, "Correct! Coughing, wheezing, and tight chest are asthma signs.")
                ),
                imageResName = "img_lungs_comparison"
            ),
            Lesson(
                id = 4,
                number = 4,
                title = "Common Asthma Triggers",
                subtitle = "Spot the sneaky things that irritate sensitive airways",
                durationMinutes = 6,
                summary = "Triggers are environmental things like dust, pollen, smoke, pet dander, and cold air that irritate lungs.",
                fullText = "An asthma 'trigger' is something that bothers your airways and causes asthma symptoms to flare up. Different children have different triggers!\n\n" +
                        "Common triggers include:\n" +
                        "- Dust mites (tiny microscopic bugs in dust and pillows)\n" +
                        "- Pollen from flowering grasses and trees in spring\n" +
                        "- Tobacco smoke and campfire smoke\n" +
                        "- Furry pets (cat or dog dander)\n" +
                        "- Cold, windy weather\n" +
                        "- Common colds and flu viruses\n" +
                        "- Strong perfumes, scented sprays, or cleaning fumes\n\n" +
                        "Being a trigger detective helps you steer clear of things that tickle your lungs!",
                quickFact = "Every person with asthma has their own personal trigger list. What triggers your friend might not bother you at all!",
                practicalTip = "Make a list with your parent of the triggers you notice most. Keeping a bedroom dust-free makes a huge difference.",
                questions = listOf(
                    ReviewQuestion(7, "Which of the following can trigger asthma symptoms?", listOf("Cold dry air", "Cigarette smoke", "Pollen from trees", "All of the above"), 3, "Super! All of these are common environmental asthma triggers."),
                    ReviewQuestion(8, "Does every child with asthma have the exact same triggers?", listOf("Yes, everyone is identical", "No, triggers are unique for each child", "Only doctors have triggers", "Triggers only exist in summer"), 1, "Spot on! Each child has their own unique set of triggers.")
                ),
                imageResName = "img_hero_mascot"
            ),
            Lesson(
                id = 5,
                number = 5,
                title = "How to Avoid Your Triggers",
                subtitle = "Smart detective habits to protect your lungs every day",
                durationMinutes = 5,
                summary = "Small daily actions like washing bedding, wrapping a scarf, and avoiding smoke keep lungs safe.",
                fullText = "You don't need a magnifying glass to be a top-notch trigger detective!\n\n" +
                        "Here are top protection strategies:\n" +
                        "- Wrap a soft scarf loosely over your mouth and nose in chilly winter air so you breathe warmed air.\n" +
                        "- Ask adults never to smoke near you, in your home, or in the car.\n" +
                        "- Wash bedsheets in warm water to reduce dust mites.\n" +
                        "- Keep furry pets out of your bedroom, and wash your hands after cuddling pets.\n" +
                        "- Check the pollen forecast in spring on high pollen days.\n" +
                        "- Wash your hands often to dodge colds and flu bugs.",
                quickFact = "Breathing in cold air through your nose warms it up naturally before it reaches your delicate lungs!",
                practicalTip = "If family or friends are cooking with strong spices or smoke, open a window or move to a well-ventilated room.",
                questions = listOf(
                    ReviewQuestion(9, "What should you do on very cold, frosty winter days?", listOf("Eat ice cream outside", "Wrap a warm scarf over your nose/mouth", "Hold your breath", "Run as fast as possible"), 1, "Warm air protects your sensitive airways from twitching in the cold!"),
                    ReviewQuestion(10, "Why is smoke harmful to lungs?", listOf("It makes airways swell and twitch", "It turns lungs purple", "It gives you extra energy", "It has no effect"), 0, "Correct! Smoke contains irritating particles that irritate breathing tubes.")
                ),
                imageResName = "img_hero_mascot"
            ),
            Lesson(
                id = 6,
                number = 6,
                title = "Asthma Medicines: Controller vs Reliever",
                subtitle = "Meet the dynamic superhero duo protecting your lungs",
                durationMinutes = 6,
                summary = "Preventer/Controller inhalers protect lungs every day; Reliever/Rescue inhalers give quick relief during symptoms.",
                fullText = "Asthma medicines usually come in two main superhero types:\n\n" +
                        "1. The CONTROLLER (or Preventer):\n" +
                        "- Often brown, orange, purple, or red.\n" +
                        "- Taken EVERY DAY, usually morning and bedtime, even when you feel 100% fantastic!\n" +
                        "- Works quietly like a shield to calm down swelling inside your airways so flare-ups don't happen.\n\n" +
                        "2. The RELIEVER (or Rescue Inhaler):\n" +
                        "- Usually BLUE.\n" +
                        "- Acts fast (within 2-5 minutes) to relax tight muscles around your airways.\n" +
                        "- Used when you start coughing, wheezing, or before exercise if recommended by your doctor.\n" +
                        "- Always keep this nearby in your backpack or school office!",
                quickFact = "A reliever inhaler relaxes muscles fast like opening a window, but a controller builds the strong walls!",
                practicalTip = "Remember: Blue = Rescue (like a lifebuoy for water). Controller = Daily shield (like brushing teeth).",
                questions = listOf(
                    ReviewQuestion(11, "Which inhaler is taken every single day to prevent symptoms from starting?", listOf("Reliever (Blue)", "Controller (Daily preventer)", "None of them", "A sweet candy"), 1, "Exactly! The controller inhaler is your daily protective superhero shield."),
                    ReviewQuestion(12, "When should a blue reliever inhaler be used?", listOf("Only on birthdays", "When you feel coughing, wheezing, or chest tightness", "Never", "Only when sleeping"), 1, "Great job! The blue reliever quickly relieves tight airway muscles.")
                ),
                imageResName = "img_inhaler_spacer"
            ),
            Lesson(
                id = 7,
                number = 7,
                title = "Why Take Medicine as Prescribed?",
                subtitle = "The secret to strong lungs: consistent daily habits",
                durationMinutes = 4,
                summary = "Controller medicine only works when taken regularly, even when you are feeling healthy.",
                fullText = "Have you ever wondered: 'I feel fine today, so why do I still need to take my inhaler?'\n\n" +
                        "Here is the secret: your controller medicine is the reason you feel so good! It keeps airway swelling asleep. If you stop taking it just because you feel fine, the swelling slowly creeps back over a few days, and a surprise flare-up can happen.\n\n" +
                        "Taking your medicine is just like brushing your teeth. You brush your teeth every day to stop cavities from forming, even if your teeth don't hurt right now!",
                quickFact = "Regular controller use cuts the chance of an asthma hospital visit by more than half!",
                practicalTip = "Link your morning and night inhaler puffs with brushing your teeth so you never forget!",
                questions = listOf(
                    ReviewQuestion(13, "Should you stop taking your daily controller inhaler if you feel totally healthy?", listOf("Yes, throw it away", "No, keep taking it as your doctor prescribed", "Only take it on weekends", "Take 10 puffs at once"), 1, "Spot on! Keeping the daily shield active is what keeps you feeling healthy!"),
                    ReviewQuestion(14, "Taking your daily inhaler is most like which good habit?", listOf("Brushing your teeth every day", "Eating cake for breakfast", "Skipping bedtime", "Never washing your hands"), 0, "Brilliant comparison! Consistent habits keep your body strong.")
                ),
                imageResName = "img_inhaler_spacer"
            ),
            Lesson(
                id = 8,
                number = 8,
                title = "Inhaler and Spacer Education",
                subtitle = "The proper technique to deliver medicine deep into your lungs",
                durationMinutes = 6,
                summary = "A spacer tube helps medication float smoothly into your lungs instead of hitting the back of your mouth.",
                fullText = "A spacer is a clear plastic holding chamber that attaches to your inhaler. It is a game-changer!\n\n" +
                        "Why use a spacer?\n" +
                        "When you spray an inhaler by itself, the medicine shoots out at over 60 miles per hour! Most of it hits your tongue or throat. With a spacer, the medicine mists gently inside the chamber, giving you time to breathe it deep into your lungs where it works magic.\n\n" +
                        "The 6 golden steps:\n" +
                        "1. Shake the inhaler well for 5 seconds.\n" +
                        "2. Connect inhaler upright to the spacer.\n" +
                        "3. Breathe out gently away from the spacer.\n" +
                        "4. Seal your lips around the mouthpiece (or hold mask firmly).\n" +
                        "5. Press the inhaler ONCE to release a puff.\n" +
                        "6. Breathe slowly and deeply 5 times in and out through the spacer!\n\n" +
                        "Rinse your mouth with water afterwards if using a steroid controller.",
                quickFact = "A spacer gets more than TWICE as much medicine into your lungs compared to using an inhaler alone!",
                practicalTip = "Always do one puff at a time into the spacer. If you need two puffs, wait 1 minute, shake, and repeat.",
                questions = listOf(
                    ReviewQuestion(15, "Why is using a spacer better than using an inhaler alone?", listOf("It looks cool", "It helps medicine reach deep into the lungs safely", "It makes medicine taste like chocolate", "It makes loud music"), 1, "Awesome! Spacers help medicine reach deep down into the airways where it is needed."),
                    ReviewQuestion(16, "How many times should you breathe in and out through the spacer after one puff?", listOf("0 times", "1 quick gasp", "5 slow, steady breaths", "50 times"), 2, "Perfect! 5 steady breaths ensure all the medicine enters your lungs.")
                ),
                imageResName = "img_inhaler_spacer"
            ),
            Lesson(
                id = 9,
                number = 9,
                title = "Physical Activity and Asthma",
                subtitle = "Yes, you can be an active athlete with asthma!",
                durationMinutes = 5,
                summary = "Exercise makes lungs stronger. Warm up, carry your reliever, and play your heart out!",
                fullText = "Did you know that many Olympic gold medalists, soccer superstars, and world-champion swimmers have asthma?\n\n" +
                        "Exercise is actually one of the best things for asthma because it strengthens your heart, lungs, and breathing muscles!\n\n" +
                        "How to play safely:\n" +
                        "- Always warm up with 5-10 minutes of gentle stretching or jogging.\n" +
                        "- If your doctor recommends it, take 2 puffs of your blue reliever 10-15 minutes before running.\n" +
                        "- Drink water and take breathers when needed.\n" +
                        "- Cool down gently after sports.\n" +
                        "- Tell your coach or teacher where your reliever inhaler is kept.",
                quickFact = "Swimming is one of the friendliest sports for asthma because pool air is warm and humid!",
                practicalTip = "Never feel embarrassed to take a quick rest on the bench if your chest feels tight. Listen to your body!",
                questions = listOf(
                    ReviewQuestion(17, "Can children with asthma participate in sports and active games?", listOf("No, they must stay in bed forever", "Yes, absolutely! Exercise strengthens your lungs", "Only if they never run", "Only indoor video games"), 1, "That's right! Exercise is great for your lungs and health."),
                    ReviewQuestion(18, "What is a smart thing to do before running fast in sports?", listOf("Warm up with gentle movement", "Carry your blue reliever inhaler", "Drink water", "All of the above"), 3, "Superstar! Warming up, hydration, and having your reliever ready keeps you safe.")
                ),
                imageResName = "img_hero_mascot"
            ),
            Lesson(
                id = 10,
                number = 10,
                title = "Recognizing Worsening Symptoms",
                subtitle = "How to spot early warning signs before a big flare-up",
                durationMinutes = 5,
                summary = "Notice when cough increases, reliever is needed more often, or sleep is disturbed.",
                fullText = "Asthma flare-ups rarely happen out of nowhere. Your body sends early yellow-light warnings:\n\n" +
                        "- Needing your blue reliever inhaler more than 2-3 times a week.\n" +
                        "- Waking up in the middle of the night coughing or wheezing.\n" +
                        "- Having trouble keeping up with friends at recess.\n" +
                        "- Feeling unusually tired or breathing faster than normal.\n\n" +
                        "When you catch these signs early, your parent and doctor can adjust your action plan before it turns into an emergency!",
                quickFact = "Keeping a simple symptom diary helps your doctor see patterns you might otherwise miss.",
                practicalTip = "If you wake up coughing at night, tell your parent in the morning so they can log it in AsthmaPlay.",
                questions = listOf(
                    ReviewQuestion(19, "What is an early sign that asthma might be getting worse?", listOf("Needing your blue reliever more often than usual", "Feeling super energetic", "Winning a race", "Laughing at a joke"), 0, "Right! Reaching for your reliever frequently means airways are irritated."),
                    ReviewQuestion(20, "What should you do if asthma wakes you up during the night?", listOf("Hide it and say nothing", "Tell your parent or caregiver right away", "Go back to sleep without medicine", "Eat snacks"), 1, "Always tell an adult! They will help you follow your asthma action plan.")
                ),
                imageResName = "img_lungs_comparison"
            ),
            Lesson(
                id = 11,
                number = 11,
                title = "Your Asthma Action Plan",
                subtitle = "The traffic light guide to feeling your best",
                durationMinutes = 5,
                summary = "The Green, Yellow, and Red zones guide your daily medicines and emergency steps.",
                fullText = "An Asthma Action Plan is a personalized guide written by your doctor. It works like a traffic light:\n\n" +
                        "🟢 GREEN ZONE (Go!):\n" +
                        "- Feeling great, no cough or wheeze, sleeping soundly.\n" +
                        "- Action: Take your regular daily controller medicine. Play as usual!\n\n" +
                        "🟡 YELLOW ZONE (Caution / Slow Down!):\n" +
                        "- Mild cough, tickly wheeze, feeling a bit tight in chest, catching a cold.\n" +
                        "- Action: Take your blue reliever inhaler via spacer. Tell an adult. Follow your doctor's yellow zone steps.\n\n" +
                        "🔴 RED ZONE (Danger / Emergency!):\n" +
                        "- Hard to breathe, hard to speak full sentences, chest pulling in under ribs, lips turning pale/blue.\n" +
                        "- Action: Take 4 puffs of reliever immediately! TELL AN ADULT NOW to call 911 / emergency services!",
                quickFact = "Every school nurse should have a copy of your doctor's official Asthma Action Plan on file.",
                practicalTip = "Ask your parent to show you where your printed action plan is kept at home on the fridge!",
                questions = listOf(
                    ReviewQuestion(21, "What color zone means you are feeling great and can play normally?", listOf("Red Zone", "Green Zone", "Purple Zone", "Black Zone"), 1, "Green means Go! You feel healthy and take your regular daily shield."),
                    ReviewQuestion(22, "What should you do if you are in the RED ZONE?", listOf("Wait 2 hours", "Immediately tell an adult and follow emergency action steps", "Take a nap", "Go play soccer"), 1, "CRITICAL: In the Red Zone, alert an adult immediately for urgent help!")
                ),
                imageResName = "img_inhaler_spacer"
            ),
            Lesson(
                id = 12,
                number = 12,
                title = "When to Seek Help from an Adult",
                subtitle = "Your superhero rule: never keep breathing struggles a secret",
                durationMinutes = 4,
                summary = "Always speak up immediately if medicine isn't helping or breathing feels difficult.",
                fullText = "The most important superhero rule of asthma:\n" +
                        "⭐ NEVER KEEP BREATHING TROUBLE A SECRET! ⭐\n\n" +
                        "Grown-ups (parents, teachers, coaches, school nurses, doctors) are on your team. They want to help you breathe easy!\n\n" +
                        "Tell an adult RIGHT AWAY if:\n" +
                        "1. Your blue reliever isn't helping after 5-10 minutes.\n" +
                        "2. It is hard to speak a full sentence without pausing to breathe.\n" +
                        "3. Your neck or tummy pulls tight when breathing.\n" +
                        "4. You feel scared about your breathing.\n\n" +
                        "Asking for help is a sign of courage and wisdom, not weakness!",
                quickFact = "Nurses and doctors love answering questions about your lungs. Never be shy to ask them!",
                practicalTip = "Practice saying this out loud: 'Excuse me teacher, my chest feels tight and I need my blue inhaler.'",
                questions = listOf(
                    ReviewQuestion(23, "Is asking an adult for help when breathing is hard a good thing?", listOf("Yes! It is the smartest and safest thing to do", "No, keep it secret", "Only if you win a game", "Never tell anyone"), 0, "Absolutely! Speaking up right away keeps you safe and supported."),
                    ReviewQuestion(24, "What should you do if your reliever inhaler doesn't ease your breathing within 10 minutes?", listOf("Sit quietly for an hour", "Tell an adult immediately so they can get medical help", "Forget about it", "Eat candy"), 1, "Spot on! If medicine doesn't help promptly, get adult assistance immediately.")
                ),
                imageResName = "img_hero_mascot"
            )
        )
    }

    private fun createInitialQuizzes(): List<Quiz> {
        return listOf(
            Quiz(
                id = "quiz_basics",
                title = "Asthma Basics Challenge",
                description = "Test your knowledge of lungs, airways, and what causes asthma flare-ups!",
                category = "General Knowledge",
                questions = listOf(
                    ReviewQuestion(1, "What happens to the airways during an asthma flare-up?", listOf("They get wider", "They swell and tighten", "They turn blue", "They stop moving"), 1, "Airways swell, produce extra mucus, and muscles tighten."),
                    ReviewQuestion(2, "Which of these is a common asthma trigger?", listOf("Cold winter air", "Pet dander", "Pollen", "All of the above"), 3, "Cold air, pet dander, and pollen are all recognized triggers."),
                    ReviewQuestion(3, "Is asthma contagious like a cold or flu?", listOf("Yes, always", "No, you cannot catch it from someone", "Only on playgrounds", "Only if coughing"), 1, "Asthma is not contagious at all!"),
                    ReviewQuestion(4, "What does a wheezing sound like?", listOf("A loud roar", "A soft musical whistle when breathing out", "A sneeze", "A pop"), 1, "Wheezing is a whistling sound made when air pushes through narrow airways.")
                ),
                completed = true,
                score = 4,
                stars = 3
            ),
            Quiz(
                id = "quiz_medicines",
                title = "Superhero Medicines Quiz",
                description = "Can you distinguish between daily controllers and fast rescue relievers?",
                category = "Medication",
                questions = listOf(
                    ReviewQuestion(5, "Which inhaler is usually blue and works quickly to relieve symptoms?", listOf("The Daily Controller", "The Reliever / Rescue inhaler", "A throat spray", "Vitamin water"), 1, "The blue reliever inhaler acts quickly to relax tight airway muscles."),
                    ReviewQuestion(6, "Why do you take your controller inhaler even when feeling completely healthy?", listOf("Because you are bored", "To keep airway swelling away and prevent flare-ups", "Only to get points", "No reason"), 1, "Daily controllers build up protection to stop symptoms before they start."),
                    ReviewQuestion(7, "What helpful clear plastic chamber is attached to an inhaler for better medicine delivery?", listOf("A telescope", "A spacer", "A straw", "A bubble tube"), 1, "A spacer ensures medicine mists smoothly deep into your lungs."),
                    ReviewQuestion(8, "What should you do after using a steroid controller inhaler?", listOf("Rinse your mouth with water and spit", "Eat dirt", "Shout loudly", "Run in circles"), 0, "Rinsing and spitting prevents hoarseness and oral thrush.")
                ),
                completed = false,
                score = 0,
                stars = 0
            ),
            Quiz(
                id = "quiz_action_plan",
                title = "Asthma Action Plan Mastery",
                description = "Master the Green, Yellow, and Red zones to stay safe everywhere!",
                category = "Emergency Action",
                questions = listOf(
                    ReviewQuestion(9, "What zone of your asthma action plan means you are feeling great?", listOf("Green Zone", "Yellow Zone", "Red Zone", "Orange Zone"), 0, "Green zone means feeling good and doing normal activities!"),
                    ReviewQuestion(10, "If your chest is tight and you are coughing during gym class, what zone are you in?", listOf("Green Zone", "Yellow Zone", "Blue Zone", "Purple Zone"), 1, "Yellow zone represents caution and worsening symptoms."),
                    ReviewQuestion(11, "If you are in the Red Zone having severe breathing difficulty, what is your top priority?", listOf("Take a nap", "Immediately tell an adult and follow emergency procedures", "Wait until tomorrow", "Keep playing"), 1, "In the Red Zone, alert an adult right away for emergency care!"),
                    ReviewQuestion(12, "Who writes your personalized Asthma Action Plan?", listOf("Your doctor / pediatrician and parents", "A television host", "A robot", "A neighbor"), 0, "Your clinician crafts your individualized plan with your parent.")
                ),
                completed = false,
                score = 0,
                stars = 0
            )
        )
    }

    // Nursing Research Study Questions (Validated 10-Question Pediatric Asthma Knowledge Assessment)
    fun getResearchQuestions(): List<ResearchQuestion> {
        return listOf(
            ResearchQuestion(1, "Asthma affects which part of your body?", listOf("Stomach", "Lungs and airways", "Bones", "Ears"), 1, "Anatomy"),
            ResearchQuestion(2, "Which of these is a fast-acting rescue medicine used when you wheeze?", listOf("Controller / Preventer", "Blue Reliever", "Antibiotic syrup", "Cough lozenge"), 1, "Medication"),
            ResearchQuestion(3, "Why is a spacer device recommended when using a metered-dose inhaler?", listOf("It makes the medicine smell nice", "It helps more medicine reach deep into the lungs", "It changes the color of the spray", "It makes a musical tune"), 1, "Inhaler Technique"),
            ResearchQuestion(4, "How long should you breathe steadily through a spacer after one puff?", listOf("1 quick second", "5 slow, deep breaths", "30 seconds", "No breathing needed"), 1, "Inhaler Technique"),
            ResearchQuestion(5, "What should you do if cold winter air triggers your cough?", listOf("Wear a warm scarf covering your mouth and nose", "Stop going to school all winter", "Never drink water", "Breathe through your mouth fast"), 0, "Trigger Avoidance"),
            ResearchQuestion(6, "Which color zone on an Asthma Action Plan means you need emergency adult help immediately?", listOf("Green Zone", "Yellow Zone", "Red Zone", "Blue Zone"), 2, "Action Plan"),
            ResearchQuestion(7, "Can children with asthma participate in school sports and physical education?", listOf("No, exercise is forbidden", "Yes, with proper warm-ups and medication if recommended", "Only during holidays", "Only if they never break a sweat"), 1, "Physical Activity"),
            ResearchQuestion(8, "Why must daily preventer / controller medication be taken even when you feel healthy?", listOf("It only works on healthy days", "It keeps swelling down inside airways to prevent future attacks", "It gives you extra homework", "It has no purpose"), 1, "Medication Adherence"),
            ResearchQuestion(9, "What is an early sign of an asthma flare-up?", listOf("Needing your reliever inhaler more frequently", "Feeling completely rested", "Having no cough", "Winning a race"), 0, "Symptom Recognition"),
            ResearchQuestion(10, "What should you do if you feel severe breathlessness and cannot speak full sentences?", listOf("Sit alone quietly and wait", "Alert an adult immediately to initiate emergency medical care", "Drink cold soda", "Go to sleep"), 1, "Emergency Response")
        )
    }
}
