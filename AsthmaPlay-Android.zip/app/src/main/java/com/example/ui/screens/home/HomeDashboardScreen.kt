package com.example.ui.screens.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.models.ChildProfile
import com.example.data.models.Lesson
import com.example.data.models.MedicationReminder
import com.example.ui.components.BreathingPacerModal
import com.example.ui.components.EmergencyBanner
import com.example.ui.theme.*

@Composable
fun HomeDashboardScreen(
    childProfile: ChildProfile,
    todayLesson: Lesson?,
    reminders: List<MedicationReminder>,
    onNavigateToLearn: () -> Unit,
    onNavigateToLesson: (Int) -> Unit,
    onNavigateToGames: () -> Unit,
    onNavigateToAssistant: () -> Unit,
    onNavigateToProgress: () -> Unit,
    onNavigateToReminders: () -> Unit,
    onNavigateToInhalerGuide: () -> Unit,
    onNavigateToSymptoms: () -> Unit,
    onOpenParentDashboard: () -> Unit,
    onToggleReminderTaken: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showBreathingModal by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FBFE))
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header Row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val avatarEmoji = when (childProfile.sex.lowercase()) {
                    "girl" -> "👧"
                    "boy" -> "👦"
                    else -> "🧒"
                }

                // Avatar
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(SkyBlueLight)
                        .border(2.dp, SkyBlueDark, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = avatarEmoji, fontSize = 30.sp)
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Hi, ${childProfile.nickname}!",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B)
                    )
                    Text(
                        text = "Age: ${childProfile.age} • ${childProfile.sex} • Keep breathing strong!",
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                }

                // Breathing Exercise Action Chip
                IconButton(
                    onClick = { showBreathingModal = true },
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(TealLight)
                ) {
                    Text(text = "🌬️", fontSize = 20.sp)
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Parent lock settings
                IconButton(
                    onClick = onOpenParentDashboard,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFF1F5F9))
                        .testTag("parent_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Parent Dashboard",
                        tint = Color(0xFF475569)
                    )
                }
            }
        }

        // 2. Today's Learning Highlight Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        todayLesson?.let { onNavigateToLesson(it.id) } ?: onNavigateToLearn()
                    }
                    .testTag("today_learning_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFFE8F5E9)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "📖", fontSize = 28.sp)
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Today's Learning",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = SoftGreenDark
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            if (todayLesson?.isCompleted == true) {
                                Text(
                                    text = "Completed! ✓",
                                    fontSize = 11.sp,
                                    color = SoftGreen,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Text(
                            text = todayLesson?.title ?: "What is Asthma?",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1E293B)
                        )

                        Text(
                            text = "Lesson ${todayLesson?.number ?: 1}  •  ${todayLesson?.durationMinutes ?: 5} min",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Open Lesson",
                        tint = SkyBlueDark
                    )
                }
            }
        }

        // 3. Quick Access Grid (6 Interactive Tiles)
        item {
            Column {
                Text(
                    text = "Quick Access",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickTile(
                        title = "Learn",
                        subtitle = "12 Lessons",
                        emoji = "📚",
                        containerColor = SkyBlueLight,
                        textColor = SkyBlueDark,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToLearn,
                        testTag = "quick_tile_learn"
                    )
                    QuickTile(
                        title = "Play Games",
                        subtitle = "Quizzes & Fun",
                        emoji = "🎮",
                        containerColor = WarmOrangeLight,
                        textColor = WarmOrange,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToGames,
                        testTag = "quick_tile_games"
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickTile(
                        title = "AI Assistant",
                        subtitle = "Ask AsthmaBuddy",
                        emoji = "🤖",
                        containerColor = RoyalPurpleLight,
                        textColor = RoyalPurple,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToAssistant,
                        testTag = "quick_tile_assistant"
                    )
                    QuickTile(
                        title = "My Progress",
                        subtitle = "${childProfile.points} Points",
                        emoji = "⭐",
                        containerColor = SoftGreenLight,
                        textColor = SoftGreenDark,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToProgress,
                        testTag = "quick_tile_progress"
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickTile(
                        title = "Inhaler Guide",
                        subtitle = "Step-by-step",
                        emoji = "💨",
                        containerColor = TealLight,
                        textColor = TealDark,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToInhalerGuide,
                        testTag = "quick_tile_inhaler"
                    )
                    QuickTile(
                        title = "Symptoms",
                        subtitle = "Daily Log",
                        emoji = "📝",
                        containerColor = Color(0xFFFFF0F5),
                        textColor = Color(0xFFC2185B),
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToSymptoms,
                        testTag = "quick_tile_symptoms"
                    )
                }
            }
        }

        // 4. Upcoming Reminders Card Section
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "🔔", fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Upcoming Reminders",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B)
                            )
                        }

                        TextButton(onClick = onNavigateToReminders) {
                            Text("View All", fontSize = 12.sp, color = SkyBlueDark)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    reminders.take(2).forEach { reminder ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFF8FAFC))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (reminder.title.contains("Reliever", ignoreCase = true)) "💨" else "💊",
                                fontSize = 22.sp
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = reminder.title,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF1E293B)
                                )
                                Text(
                                    text = "${reminder.timeString}  •  ${reminder.dosageNotes}",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }

                            Checkbox(
                                checked = reminder.isTakenToday,
                                onCheckedChange = { onToggleReminderTaken(reminder.id) }
                            )
                        }
                    }
                }
            }
        }

        // 5. Breathing Mascot Mini-Banner
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = SkyBlueLight),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showBreathingModal = true }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "🫁", fontSize = 32.sp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Relax Your Breathing",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = SkyBlueDark
                        )
                        Text(
                            text = "Take 3 deep gentle breaths with our Lung Mascot buddy!",
                            fontSize = 11.sp,
                            color = Color(0xFF0369A1)
                        )
                    }
                    FilledTonalButton(
                        onClick = { showBreathingModal = true },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = SkyBlueDark,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("Start", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 6. Emergency Red Alert Banner
        item {
            EmergencyBanner(
                doctorPhone = childProfile.emergencyDoctorPhone,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    if (showBreathingModal) {
        BreathingPacerModal(
            onDismiss = { showBreathingModal = false },
            onCompleted = { showBreathingModal = false }
        )
    }
}

@Composable
private fun QuickTile(
    title: String,
    subtitle: String,
    emoji: String,
    containerColor: Color,
    textColor: Color,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        modifier = modifier
            .height(96.dp)
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Text(text = emoji, fontSize = 24.sp)
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = textColor.copy(alpha = 0.7f),
                    modifier = Modifier.size(16.dp)
                )
            }

            Column {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = textColor
                )
                Text(
                    text = subtitle,
                    fontSize = 10.sp,
                    color = textColor.copy(alpha = 0.8f)
                )
            }
        }
    }
}
