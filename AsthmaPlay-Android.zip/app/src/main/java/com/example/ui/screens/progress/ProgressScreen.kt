package com.example.ui.screens.progress

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Badge
import com.example.data.models.ChildProfile
import com.example.data.models.Lesson
import com.example.data.models.Quiz
import com.example.ui.components.BreathingPacerModal
import com.example.ui.theme.*

@Composable
fun ProgressScreen(
    childProfile: ChildProfile,
    lessons: List<Lesson>,
    quizzes: List<Quiz>,
    badges: List<Badge>,
    onAwardBreathingPoints: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showBreathingModal by remember { mutableStateOf(false) }

    val completedLessons = lessons.count { it.isCompleted }
    val avgQuizScore = if (quizzes.any { it.completed }) {
        val completed = quizzes.filter { it.completed }
        (completed.sumOf { it.score }.toFloat() / completed.sumOf { it.questions.size } * 100).toInt()
    } else 85

    val unlockedBadgesCount = badges.count { it.isUnlocked }

    // Level calculation (next goal 500 XP)
    val nextLevelTarget = 500
    val progressPercent = (childProfile.points.toFloat() / nextLevelTarget).coerceIn(0f, 1f)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FBFE))
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Profile Level Header Card
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val avatarEmoji = when (childProfile.sex.lowercase()) {
                        "girl" -> "👧"
                        "boy" -> "👦"
                        else -> "🧒"
                    }

                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(SkyBlueLight)
                            .border(3.dp, SkyBlueDark, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = avatarEmoji, fontSize = 42.sp)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = childProfile.nickname,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B)
                    )

                    Text(
                        text = "Age: ${childProfile.age} • ${childProfile.sex}",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )

                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = SoftGreenLight,
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Text(
                            text = childProfile.levelName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = SoftGreenDark,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // XP Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Learning Experience",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.Gray
                        )
                        Text(
                            text = "${childProfile.points} / $nextLevelTarget XP",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = SkyBlueDark
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { progressPercent },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(CircleShape),
                        color = SkyBlueDark,
                        trackColor = Color(0xFFE2E8F0)
                    )
                }
            }
        }

        // 2. Metrics 4-Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "Lessons",
                    value = "$completedLessons/${lessons.size}",
                    emoji = "📖",
                    color = SkyBlueDark,
                    bg = SkyBlueLight,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Quiz Score",
                    value = "$avgQuizScore%",
                    emoji = "🏆",
                    color = WarmOrange,
                    bg = WarmOrangeLight,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard(
                    title = "Badges",
                    value = "$unlockedBadgesCount",
                    emoji = "⭐",
                    color = RoyalPurple,
                    bg = RoyalPurpleLight,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Streak",
                    value = "${childProfile.streakDays} days",
                    emoji = "🔥",
                    color = Color(0xFFE65100),
                    bg = Color(0xFFFFE0B2),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 3. Guided Breathing Mini-Game Button
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = TealLight),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showBreathingModal = true }
                    .testTag("progress_breathing_banner")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "🌬️", fontSize = 32.sp)
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Practice Guided Breathing",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TealDark
                        )
                        Text(
                            text = "Calm your airways with 3 gentle rounds & earn +10 XP!",
                            fontSize = 12.sp,
                            color = Color(0xFF00695C)
                        )
                    }
                    Button(
                        onClick = { showBreathingModal = true },
                        colors = ButtonDefaults.buttonColors(containerColor = TealDark),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Start", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // 4. Badges Collection Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Superhero Badges",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )
                Text(
                    text = "$unlockedBadgesCount of ${badges.size} Unlocked",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }

        // Badges list items
        items(badges) { badge ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (badge.isUnlocked) Color.White else Color(0xFFF1F5F9)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = if (badge.isUnlocked) 2.dp else 0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(if (badge.isUnlocked) GoldenYellowLight else Color(0xFFE2E8F0)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (badge.isUnlocked) badge.iconEmoji else "🔒",
                            fontSize = 24.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = badge.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (badge.isUnlocked) Color(0xFF1E293B) else Color.Gray
                        )
                        Text(
                            text = badge.description,
                            fontSize = 12.sp,
                            color = if (badge.isUnlocked) Color(0xFF64748B) else Color.LightGray
                        )
                        if (badge.isUnlocked && badge.unlockedDate.isNotBlank()) {
                            Text(
                                text = badge.unlockedDate,
                                fontSize = 10.sp,
                                color = SoftGreenDark,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }

    if (showBreathingModal) {
        BreathingPacerModal(
            onDismiss = { showBreathingModal = false },
            onCompleted = {
                showBreathingModal = false
                onAwardBreathingPoints()
            }
        )
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    emoji: String,
    color: Color,
    bg: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        modifier = modifier.height(84.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = emoji, fontSize = 28.sp)
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = value,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = color
                )
                Text(
                    text = title,
                    fontSize = 11.sp,
                    color = color.copy(alpha = 0.8f)
                )
            }
        }
    }
}
