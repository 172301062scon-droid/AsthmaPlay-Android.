package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// AsthmaPlay Brand Palette
// Primary colors: sky blue, white, teal, soft green
val SkyBluePrimary = Color(0xFF38B6FF)
val SkyBlueDark = Color(0xFF0288D1)
val SkyBlueLight = Color(0xFFE1F5FE)

val TealAccent = Color(0xFF00B4D8)
val TealDark = Color(0xFF0077B6)
val TealLight = Color(0xFFE0F7FA)

val SoftGreen = Color(0xFF4CAF50)
val SoftGreenLight = Color(0xFFE8F5E9)
val SoftGreenDark = Color(0xFF2E7D32)

// Secondary colors: orange, yellow, purple for rewards and games
val WarmOrange = Color(0xFFFF9800)
val WarmOrangeLight = Color(0xFFFFF3E0)
val GoldenYellow = Color(0xFFFFC107)
val GoldenYellowLight = Color(0xFFFFFDE7)

val RoyalPurple = Color(0xFF8E24AA)
val RoyalPurpleLight = Color(0xFFF3E5F5)

// Danger & Emergency
val EmergencyRed = Color(0xFFE53935)
val EmergencyRedLight = Color(0xFFFFEBEE)

// Neutrals
val BackgroundLight = Color(0xFFF8FBFE)
val SurfaceCard = Color(0xFFFFFFFF)
val TextDark = Color(0xFF1E293B)
val TextMuted = Color(0xFF64748B)
val BorderLight = Color(0xFFE2E8F0)
