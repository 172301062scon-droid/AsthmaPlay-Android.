package com.example.ui.screens.welcome

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.models.UserRole
import com.example.ui.theme.SkyBlueDark
import com.example.ui.theme.SkyBlueLight
import com.example.ui.theme.TealAccent

@Composable
fun LoginRegisterScreen(
    currentNickname: String,
    currentAge: Int,
    currentSex: String = "Boy",
    onSuccessLogin: (UserRole, String, Int, String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isRegisterMode by remember { mutableStateOf(false) }
    var selectedRole by remember { mutableStateOf(UserRole.CHILD) }

    var emailOrPhone by remember { mutableStateOf("parent@asthmaplay.org") }
    var password by remember { mutableStateOf("••••••••") }
    var childNickname by remember { mutableStateOf(currentNickname) }
    var childAge by remember { mutableIntStateOf(currentAge) }
    var childSex by remember { mutableStateOf(currentSex) }
    var researchCode by remember { mutableStateOf("AP-2026-042") }
    var consentAccepted by remember { mutableStateOf(true) }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FBFE))
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Back row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "AsthmaPlay Account",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = SkyBlueDark
            )
            Spacer(modifier = Modifier.weight(1f))
            Spacer(modifier = Modifier.size(48.dp))
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Mascot Icon
        Card(
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.size(80.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_app_icon),
                contentDescription = "AsthmaPlay Logo",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = if (isRegisterMode) "Create Family Account" else "Welcome Back!",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1E293B)
        )
        Text(
            text = "Sign in to continue your journey to better breathing.",
            fontSize = 13.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Role Selector Chips
        Text(
            text = "Choose Access Mode:",
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF334155),
            modifier = Modifier.align(Alignment.Start)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedRole == UserRole.CHILD,
                onClick = { selectedRole = UserRole.CHILD },
                label = { Text("👶 Child Mode") },
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = selectedRole == UserRole.PARENT,
                onClick = { selectedRole = UserRole.PARENT },
                label = { Text("👨‍👩‍👧 Parent") },
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = selectedRole == UserRole.RESEARCHER,
                onClick = { selectedRole = UserRole.RESEARCHER },
                label = { Text("🔬 Research") },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Mode specific fields
        if (selectedRole == UserRole.RESEARCHER) {
            OutlinedTextField(
                value = researchCode,
                onValueChange = { researchCode = it },
                label = { Text("Participant Study Code") },
                leadingIcon = { Icon(Icons.Default.Science, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("research_code_input")
            )
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF3E5F5)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Research Mode: 'Effectiveness of an AI-Based Asthma Education Application on Asthma Self-Management Knowledge Among School-Age Children'. De-identified study participant data only.",
                    fontSize = 11.sp,
                    color = Color(0xFF4A148C),
                    modifier = Modifier.padding(12.dp),
                    lineHeight = 15.sp
                )
            }
        } else {
            OutlinedTextField(
                value = emailOrPhone,
                onValueChange = { emailOrPhone = it },
                label = { Text("Parent Email or Phone") },
                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("email_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("password_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = childNickname,
                onValueChange = { childNickname = it },
                label = { Text("Child's Nickname") },
                leadingIcon = { Icon(Icons.Default.Face, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("child_nickname_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Child age picker
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Child's Age: $childAge years",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
                Row {
                    IconButton(
                        onClick = { if (childAge > 6) childAge-- },
                        enabled = childAge > 6
                    ) {
                        Icon(Icons.Default.RemoveCircle, contentDescription = "Decrease Age")
                    }
                    IconButton(
                        onClick = { if (childAge < 12) childAge++ },
                        enabled = childAge < 12
                    ) {
                        Icon(Icons.Default.AddCircle, contentDescription = "Increase Age")
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Child sex selection
            Text(
                text = "Child's Sex: $childSex",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF334155),
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Boy", "Girl", "Other").forEach { option ->
                    FilterChip(
                        selected = childSex == option,
                        onClick = { childSex = option },
                        label = { Text(option) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        if (errorMessage != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = errorMessage ?: "",
                color = MaterialTheme.colorScheme.error,
                fontSize = 12.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Privacy and Parental Consent disclaimer
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = consentAccepted,
                onCheckedChange = { consentAccepted = it }
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "Parental consent verified. Health data is protected and kept private.",
                fontSize = 12.sp,
                color = Color.DarkGray
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                if (!consentAccepted) {
                    errorMessage = "Please accept the parental consent terms to proceed."
                    return@Button
                }
                if (childNickname.isBlank()) {
                    errorMessage = "Please enter your child's nickname."
                    return@Button
                }
                onSuccessLogin(selectedRole, childNickname, childAge, childSex)
            },
            colors = ButtonDefaults.buttonColors(containerColor = SkyBlueDark),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("submit_login_button")
        ) {
            Text(
                text = if (isRegisterMode) "Create Account & Enter" else "Login / Enter App",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        TextButton(
            onClick = { isRegisterMode = !isRegisterMode }
        ) {
            Text(
                text = if (isRegisterMode) "Already have an account? Sign In" else "New to AsthmaPlay? Create Account",
                color = SkyBlueDark,
                fontSize = 13.sp
            )
        }
    }
}
