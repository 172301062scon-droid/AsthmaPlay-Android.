package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.AsthmaRepository
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("AsthmaPlay", appName)
  }

  @Test
  fun `repository initial state and lesson progress`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = AsthmaRepository(context)

    assertEquals("Arjun", repo.childProfile.value.nickname)
    assertEquals(8, repo.childProfile.value.age)
    assertEquals(12, repo.lessons.value.size)

    val initialPoints = repo.childProfile.value.points
    repo.markLessonCompleted(12)
    assertTrue(repo.lessons.value.first { it.id == 12 }.isCompleted)
    assertTrue(repo.childProfile.value.points > initialPoints)
  }

  @Test
  fun `parent PIN verification and update`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = AsthmaRepository(context)

    assertTrue(repo.verifyParentPin("1234"))
    assertFalse(repo.verifyParentPin("9999"))

    assertTrue(repo.updateParentPin("5678"))
    assertTrue(repo.verifyParentPin("5678"))
    assertFalse(repo.verifyParentPin("1234"))
  }

  @Test
  fun `update child profile with age and sex`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = AsthmaRepository(context)

    repo.updateChildProfile("Riya", 10, "Girl", "Dr. Sharma", "911")
    assertEquals("Riya", repo.childProfile.value.nickname)
    assertEquals(10, repo.childProfile.value.age)
    assertEquals("Girl", repo.childProfile.value.sex)
  }
}
